    /*Temperature Converter*/
        
        
       function celsiusToFahrenheit() /* function to convert celsius to fahrenheit*/
        {
            var celvalue=document.getElementById('Cel').value; // Reading the value of celsius and storing in a variable
            if(celvalue=="")                                   //Validating Null value  
                {
                    alert("Please enter value for Celsius");  //Error Message for null fields.
                }
            else
                {
                    var convfar= ((celvalue*9)/5)+32;           // Formula to convert celsius to fahrenheit
                    document.getElementById('msgprnt').innerHTML=celvalue + "&deg;C  is  " + convfar+"&deg;F";//Display message after conversion
                }
        }
        
        function fahrenheitToCelsius()  /* function to convert fahrenheit to celsius*/
        {
            var farvalue=document.getElementById('Far').value; // Reading the value of fahrenheit and storing in a variable
            if(farvalue=="")                                    //Validating Null value  
                {
                    alert("Please enter value for Fahrenheit");//Error Message for null fields.
                }
            
            else
                {
                    var convcel= ((farvalue-32)*5)/9;       // Formula to convert fahrenheit to celsius
                    document.getElementById('msgprnt').innerHTML=farvalue + "&deg;F  is  " + convcel+"&deg;C";//Display message after conversion
                }
        }
        
        
        
        
        /*The Geometrizer*/
        
        
        function calcCircumfrence()  //function to calculate Circumference of a circle
        {
            var readRad= document.getElementById('rad').value; // Reading the value of Radius and storing in a variable
            if(readRad=="" || readRad<=0)                       // Validating Null and Boundary conditions
                {
                    alert("Please enter valid value for Radius of the Circle");//Error message if validaton fails
                }
            else
                {
            var circumference=2*3.14*readRad;                       // Formula to calculate the Circumference of a circle
            document.getElementById('msgprnt1').innerHTML="Circumference of a Circle is "+circumference; // Display message after calculation
                }
        }
        
        function calcArea() //  Function to calculate the Area of the circle
        {
            var readrad1= document.getElementById('rad').value; // Reading the value of Radius and storing in a variable
            if(readrad1=="" || readrad1<=0)                     // Validating Null and Boundary conditions
                {
                    alert("Please enter valid value for Radius of the Circle");//Error message if validaton fails
                }
            else
                {
            var area=3.14*(readrad1*readrad1);                          // Formula to calculate the Area of a circle
            document.getElementById('msgprnt1').innerHTML="Area of a Circle is "+area;// Display message after calculation
                }
        } 
        
        
        
        
        
        
        /*The Lifetime Supply Calculator*/
        
        function callsupply(){ 
            
            var agetxt=document.getElementById('age').value;/*Reading the values of age and amount, Storing in the*/ 
            var amtpd= document.getElementById('amt').value;/*varaible*/
    
            
            if(agetxt>0 && agetxt<100 && agetxt!="" && amtpd!="" && amtpd>0) // Validating Null and Boundary conditions
               {
           var cal1= calculateSupply(agetxt,amtpd); // Calling calculateSupply(x,y) function and storing the return value into a variable
                   
                   document.getElementById('msgprnt2').innerHTML="You will need "+ cal1+"&#8377; to last you until the ripe old age of 100";
                   var cal2=calculateSupply(40,100);
                   document.getElementById('msgprnt3').innerHTML="You will need "+ cal2+"&#8377; to last you until the ripe old age of 100 if you spend 100&#8377; per day at the age of 40";
                   var cal3=calculateSupply(25,250);
                   document.getElementById('msgprnt4').innerHTML="You will need "+ cal3+"&#8377; to last you until the ripe old age of 100 if you spend 250&#8377; per day at the age of 25";
        }
            else{
                alert("Enter the valid amount"); // Display error message if validation fails
            }
            
        }
        
        function calculateSupply(x,y) // Function to calculate 
        {
            var estimate=((100-x)*365)*y; // Formula to estimate the supply
            return estimate;              //Return the estimate value
        }
        
        
        
        
        /*Age Calculator*/
        
        function getcuryear() //Function to fetch the current year on focus of Current Date field
        {
            var curdt=new Date();
            var cryer= curdt.getFullYear();
            document.getElementById('curyr').value=cryer;
        }
        function calage(){ 
            
            var bdt= document.getElementById('birthyr').value; /*Reading the values of age and amount, Storing in the*/  
            var cdt= document.getElementById('curyr').value;   /*varaible*/
            
            if(bdt<cdt && bdt>0)                               //Validating Boundary 
            {
            var ag1=calculateAge(bdt,cdt);                      //Calling calculateAge(x,y) function to calculate age and storing the return value into a variable.
            document.getElementById('msgprnt5').innerHTML="You are either "+(ag1-1)+" or"+(ag1);
            var ag2=calculateAge(1994,cdt);
            document.getElementById('msgprnt6').innerHTML="You are either "+(ag2-1)+" or"+(ag2) + " if your birth date is 1994";
            var ag3=calculateAge(2000,cdt);
            document.getElementById('msgprnt7').innerHTML="You are either "+(ag3-1)+" or"+(ag3) + " if your birth date is 2000";
            }
            else
                {
                  alert("Please enter valid BirthDate within CurrentDate"); //Error message if validation fails 
                }
        }
        
        function calculateAge(byr,cyr) // Function to calculate actual age
        {
            var acag=cyr-byr;           //Formula to calculate actual age
            return acag;                //Return Actual age
        }